#include "LinkedList.h"




LinkedList::LinkedList()
{
	this->first = NULL;
}


LinkedList::~LinkedList()
{
}

//*****IS EMPTY
bool LinkedList::isEmpty()
{
	//want to see if the list is empty when we start off
	//if its empty return true
	//if it has values in it, return false
	if (this->first == NULL)
		return true;
	else
		return false;
}

//****INSERT AS FIRST LETTER
void LinkedList::insertAsFirstElement(string data)
{
	//creating a temporary node
	//pointing to a new number
	//the temp pointer is referencing a number which is assigned by "int number"
	//the next node will be NULL 
	//after everything is inserted, the head is set to temp and the last is set to temp
	Node *temp = new Node;
	temp->data = data;
	temp->next = NULL;
	
	this->first = temp;
}


//******INSERT
void LinkedList::insert( string data)
{
	    Node *temp = new Node;
		temp->data = data;
		temp->next = NULL;
		

		Node *n = first;
		while (n->next != NULL)
		{
			n = n->next;
		}
		n->next = temp;
		
}


string LinkedList::getLine(int lineNum)
{
	int i = 0;
	Node *n = this->first;


	while (i != lineNum)
	{
		n = n->next;
		i++;
	}
	return n->data;
}

//*****DELETE ELEMEMT
void LinkedList::deleteElement(int lineNum)
{
	if (lineNum == 0)
	{
		deleteFirstNode();
	}
	else
	{
		int i = 0;
		Node *n2, *n = this->first;

		while (i != (lineNum - 1))
		{
			n = n->next;
			i++;
		}
		//storing a pointer to the line before the line to be deleted
		n2 = n;
		//incrementing to the line to be deleted
		n = n->next;
		//setting the next property of the line before this one, to be the line after this one
		n2->next = n->next;
		//deleting this line
		delete n;
	}
	
}

void LinkedList::insertBeforeIndex(string newLine, int lineNum)
{
	int i = 0;
	Node *n = this->first;


	while (i != (lineNum - 1))
	{
		n = n->next;
		i++;
	}

	//MAke a new node to hold a new line.
	Node *newNode = new Node;
	newNode->data = newLine;
	//the new node will point to the index supplied
	newNode->next = n->next;
	// the current node(before the index) will point to this new node
	n->next = newNode;
}
	void LinkedList::substitute(string newLine, int lineNum)
	{
		int i = 0;
		Node *n2, *n = this->first;


		while (i != (lineNum - 1))
		{
			n = n->next;
			i++;
		}

		//MAke a new node to hold a new line.
		Node *newNode = new Node;
		newNode->data = newLine;


		//storing our grasp on the node before the node being replaced
		n2 = n;
		//Incrementing to node to be replaced
		n = n->next;

		//setting the node before this one to point to the new node
		n2->next = newNode;

		//Seting the new node to point to the next node
		newNode->next = n->next;

		//deletig the current node
		delete n;

	}

	void LinkedList::deleteFirstNode()
	{
		Node *n = this->first;
		this->first = this->first->next;
		delete n;
	}
	

